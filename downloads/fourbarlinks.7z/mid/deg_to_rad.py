import math

deg = 2*math.pi/360.

print(round(90*deg, 4))
print(round(55.12*deg, 4))
print(round(89.47*deg, 4))